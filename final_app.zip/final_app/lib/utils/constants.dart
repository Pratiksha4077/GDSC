const List<String> categories = ['Length', 'Weight', 'Temperature', 'Currency'];
